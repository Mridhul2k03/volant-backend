from django.apps import AppConfig


class VolantappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'volantapp'
